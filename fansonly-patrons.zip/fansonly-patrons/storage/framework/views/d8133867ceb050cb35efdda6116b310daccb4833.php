<div>
    <?php echo $__env->make('creators.loop', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
<?php /**PATH /Users/crivion/Sites/patrons/resources/views/livewire/creators-sidebar.blade.php ENDPATH**/ ?>