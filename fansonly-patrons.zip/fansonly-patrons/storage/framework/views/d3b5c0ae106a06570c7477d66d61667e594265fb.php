<div class="col-12 d-block d-sm-block d-md-none mb-4">
	
</div><?php /**PATH /Users/crivion/Sites/patrons/resources/views/posts/sidebar-mobile.blade.php ENDPATH**/ ?>