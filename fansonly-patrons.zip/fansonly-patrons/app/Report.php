<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Report extends Model
{
    // no timestamps, please
    public $timestamps = false;
}
