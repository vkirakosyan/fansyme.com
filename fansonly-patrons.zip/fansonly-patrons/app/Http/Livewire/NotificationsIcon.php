<?php

namespace App\Http\Livewire;

use Livewire\Component;

class NotificationsIcon extends Component
{
    public function render()
    {
        return view('livewire.notifications-icon');
    }
}
