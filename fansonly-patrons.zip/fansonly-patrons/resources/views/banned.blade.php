<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<center>
    <h3>@lang('v18.banned-message')</h3>
</center>

<script>
    setTimeout(function(){
       window.location.href = 'https://www.google.com';
    }, 3000);
</script>