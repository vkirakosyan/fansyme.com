@extends('admin.base')

@section('section_title')
	<strong>Payments Settings</strong>
@endsection

@section('section_body')

@livewire('admin-payment-settings')

@endsection