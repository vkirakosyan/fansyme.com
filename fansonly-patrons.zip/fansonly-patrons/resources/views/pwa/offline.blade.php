@extends('welcome')

@section('content')

<div class="container">
<div class="card shadow p-3 mt-5">
    <h3 class="p-5">
        <i class="fas fa-network-wired"></i> @lang('v17.pwaOffline')
    </h3>
</div>
</div>

@endsection