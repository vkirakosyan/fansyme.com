<?php

return [
    'zipUpload' => 'ZIP Upload',
    'zipDownload' => 'Download ZIP',
    'accessDenied' => 'You do not have access to this file',
];