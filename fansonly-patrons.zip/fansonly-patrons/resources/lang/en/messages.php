<?php
return [
    'messages'    => 'Messages',
    'sendMessage' => 'Send Message',
    'contacts'    => 'Contacts',
    'inbox'       => 'Inbox',
    'to'          => 'To',
    'writeAndPressEnter' => 'Write your message and press enter',
    'enterSomething' => 'Enter at least 1 character',
    'newMessages' => 'new',
];
